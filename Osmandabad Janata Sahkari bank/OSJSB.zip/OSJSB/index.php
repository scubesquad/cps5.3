<?php
header("Location: http://localhost/OSJSB/login.php");
exit();
?>