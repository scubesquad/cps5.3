<?php
header("Location: http://localhost/amravati/login.php");
exit();
?>