<title>:: Cheque Personalization System ::</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css"  href="<?php echo ADMIN_STYLES; ?>stylecss.css" />
<script type="text/javascript" src="<?php echo ROOT_SCRIPTS; ?>jquery-1.4.2.min.js"></script>
<link rel="stylesheet" type="text/css" href="<?php echo ROOT_STYLES; ?>jquery-ui-1.8.2.custom.css" />
<script type="text/javascript" src="<?php echo ROOT_SCRIPTS; ?>jquery-ui-1.8.2.custom.min.js" ></script>
<script type="text/javascript" src="<?php echo ROOT_SCRIPTS; ?>jquery.form.js"></script>
<script type="text/javascript" src="<?php echo ROOT_SCRIPTS; ?>jquery.validate.js" ></script>
<script type="text/javascript" src="<?php echo ROOT_SCRIPTS; ?>dropdowntabs.js" ></script>