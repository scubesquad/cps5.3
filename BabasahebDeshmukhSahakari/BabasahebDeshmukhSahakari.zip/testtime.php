<?php
echo substr(str_pad('1234567891', 3, "0", STR_PAD_LEFT),-6);

?>